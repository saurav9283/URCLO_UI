export const images = [
    {
      "image": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSIrCyEI9WvgTcFDHyCwpnakBX0BXx9KPiCOA&s",
      "title": "Carpenter"
    },
    {
      "image": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQbagKTSn3vrmgTKqwJc6_MikMIupyL220Vqg&s",
      "title": "Electician"
    },
    {
      "image": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQOOEh8cIP3lZeU1g5TKwlkxgCC3ON99Dz8UQ&s",
      "title": "Gardener"
    },
    {
      "image": "https://img.freepik.com/free-vector/hand-drawn-painter-cartoon-illustration_23-2151046691.jpg",
      "title":"Painter"
    },
    {
      "image": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRQiMF9j_u5DapPtHPQ9VTBhlPTN4ITPidiSA&s",
      "title":"Plumber"
    },
    {
        "image": "https://t3.ftcdn.net/jpg/02/68/92/26/240_F_268922696_5kbXfVlINifHiY2HUzbsbVZtJhfCP3HL.jpg",
        "title": "Cleaner"
      }
  ];

  export const carouselNew = [
   
    {
      "image": "https://res.cloudinary.com/urbanclap/image/upload/t_high_res_template/w_233,dpr_1,fl_progressive:steep,q_auto:low,f_auto,c_limit/images/growth/luminosity/1687428458328-9e147d.jpeg",
      "title": "Native Water Purifier",
    },
    {
      "image": "https://res.cloudinary.com/urbanclap/image/upload/t_high_res_template/w_233,dpr_1,fl_progressive:steep,q_auto:low,f_auto,c_limit/images/growth/luminosity/1651040419628-022a2b.jpeg",
      "title": "Painting & Waterproofing",
    },
    {
      "image": "https://res.cloudinary.com/urbanclap/image/upload/t_high_res_template/w_233,dpr_1,fl_progressive:steep,q_auto:low,f_auto,c_limit/images/growth/luminosity/1651040413083-4699a6.jpeg",
      "title": "Nail Studio for Women",
    },
    {
      "image": "https://res.cloudinary.com/urbanclap/image/upload/t_high_res_template/w_233,dpr_1,fl_progressive:steep,q_auto:low,f_auto,c_limit/images/growth/luminosity/1651040420198-fe6d1d.jpeg",
      "title": "Hair Studio for Women",
    },
    {
        "image": "https://res.cloudinary.com/urbanclap/image/upload/t_high_res_template/w_233,dpr_1,fl_progressive:steep,q_auto:low,f_auto,c_limit/images/growth/luminosity/1652853823570-152440.png",
        "title": "AC Repair",
      },
    {
        "image": "https://res.cloudinary.com/urbanclap/image/upload/t_high_res_template/w_233,dpr_1,fl_progressive:steep,q_auto:low,f_auto,c_limit/images/growth/home-screen/1681371120474-301f47.jpeg",
        "title": "Cleaning",
      }
  ];
  