import React from 'react'
import Register from './Register'

const HandleRegister = () => {
  return (
    <>
    <div>
      <Register />
    </div>
    </>
  )
}

export default HandleRegister